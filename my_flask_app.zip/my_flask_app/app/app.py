from flask import Flask
from flask import jsonify
from celery import Celery

app= Flask(__name__)
console_event_app=Celery('console_event',broker='redis://redis:6379/0',backend='redis://redis:6379/0')

@app.route('/create_event/<message>')
def add_event_queue(message:str):
    '''Service adds event in a queue.'''

    message_event=console_event_app.send_task('tasks.console_event_task',kwargs={'message':"hello"+" "+message})
    return jsonify({"task_id":message_event.id})

@app.route('/event_status/<taskid>')
def find_event_status(taskid:str):
    '''Service provides event status in queue.'''

    status=console_event_app.AsyncResult(taskid, app=console_event_app)
    return jsonify({"event_status":status.state})

@app.route('/task_result/<taskid>')
def task_result(taskid:str):
    '''Get the task result using this service.'''

    result = console_event_app.AsyncResult(taskid).result
    return jsonify({"task_result":str(result)})





